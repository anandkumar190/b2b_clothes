
<?php $__env->startSection('title','Create Certificate'); ?>
<?php $__env->startSection('content'); ?>
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Certificate Master</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title margin-mb">Add Certificate Name</h4>
                                        <ul class="nav nav-tabs nav-bordered mb-1">
                                        </ul> <!-- end nav-->
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="custom-styles-preview">
                                                <form id="add_certi" action="<?php echo e(route('certificate.store')); ?>" method="post">
                                                <?php echo $__env->make('admin.certificate.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php echo csrf_field(); ?>
                                                </form>                                            
                                            </div> <!-- end preview-->
                                        </div> <!-- end tab-content-->

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->

                    </div> <!-- container -->

                </div> <!-- content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
$.validator.setDefaults({
        submitHandler : function(form) {
            form.submit();
        }
    });
    $("#add_certi").validate({

            rules: {
                blend_content_name: "required",
            },

            messages: {
                blend_content_name: "* Enter Blend Name",
            }
        });
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomm\resources\views/admin/certificate/create.blade.php ENDPATH**/ ?>