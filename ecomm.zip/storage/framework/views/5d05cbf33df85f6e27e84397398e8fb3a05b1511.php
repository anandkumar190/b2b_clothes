                                                    <div class="form-group mb-3">
                                                        <label for="validationCustom01">Blend Content Name</label>
                                                        <input type="text" class="form-control" id="validationCustom01"
                                                            placeholder="Blend Content name" name="blend_content_name" value="<?php echo e($data->blend_content_name); ?>" required>
                                                        <div class="valid-feedback">
                                                            Done !!
                                                        </div>
                                                    </div>
                                                    <div class="form-group mb-3">
                                                        <label for="validationCustom02">Status</label>
                                                        <select name="is_active" id="validationCustom02" class="form-control">
                                                            <option value="" selected="true" disabled>Select</option>
                                                            <?php $__currentLoopData = $data->activeOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeOptionkey => $activeOptionValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($activeOptionkey); ?>" <?php echo e($activeOptionValue == $data->is_active ? 'selected' : ''); ?>><?php echo e($activeOptionValue); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <div class="valid-feedback">
                                                            Done !!
                                                        </div>
                                                    </div>
                                                    <button class="btn btn-primary" type="submit">Submit form</button><?php /**PATH C:\xampp\htdocs\ecomm\resources\views/admin/blendContent/form.blade.php ENDPATH**/ ?>