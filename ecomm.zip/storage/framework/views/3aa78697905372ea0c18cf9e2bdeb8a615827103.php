<!DOCTYPE html>
    <html lang="en">
<head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(url('public/admin/images/favicon.ico')); ?>">
        <!-- third party css -->
        <link href="<?php echo e(url('public/admin/css/vendor/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(url('public/admin/css/vendor/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(url('public/admin/css/vendor/buttons.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(url('public/admin/css/vendor/select.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(url('public/admin/css/vendor/jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- third party css end -->
        <!-- App css -->
        <link href="<?php echo e(url('public/admin/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(url('public/admin/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
        <link href="<?php echo e(url('public/admin/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
        <!-- Begin page -->
        <div class="wrapper">
            <!-- ========== Left Sidebar Start ========== -->
          

            <div class="left-side-menu">
    
                    <!-- LOGO -->
                    <a href="index.html" class="logo text-center logo-light">
                        <span class="logo-lg">
                            <img src="assets/images/logo.png" alt="" height="16">
                        </span>
                        <span class="logo-sm">
                            <img src="assets/images/logo_sm.png" alt="" height="16">
                        </span>
                    </a>

                    <!-- LOGO -->
                    <a href="index.html" class="logo text-center logo-dark">
                        <span class="logo-lg">
                            <img src="assets/images/logo-dark.png" alt="" height="16">
                        </span>
                        <span class="logo-sm">
                            <img src="assets/images/logo_sm_dark.png" alt="" height="16">
                        </span>
                    </a>

                    <div class="h-100" id="left-side-menu-container" data-simplebar>
                        <!--- Sidemenu -->
                        <ul class="metismenu side-nav">
                            <li class="side-nav-title side-nav-item">Navigation</li>
                            <?php if(Auth()->user()->user_type == '1'): ?>
                            <li class="side-nav-item">
                                <a href="<?php echo e(route('admin_index')); ?>" class="side-nav-link" aria-expanded="false">
                                    <i class="uil-home-alt"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>
                            <li class="side-nav-item">
                                <a href="javascript: void(0);" class="side-nav-link" aria-expanded="false">
                                    <i class="uil-store"></i>
                                    <span> Master Data </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="side-nav-second-level mm-collapse" aria-expanded="false">
                                    <li>
                                        <a href="<?php echo e(route('category.index')); ?>">Category</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('subcategory.index')); ?>">Sub-Category</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('weave.index')); ?>">Weave</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('tradename.index')); ?>">Trade Name</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('finish.index')); ?>">Finish</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('color.index')); ?>">Color</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('blendContent.index')); ?>">Blend/Content</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('certificate.index')); ?>">Certificate</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('price.index')); ?>">Price</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('price.index')); ?>">Price</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('wrapCount.index')); ?>">Wrap Count</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('weftCount.index')); ?>">Weft Count</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('quantity.index')); ?>">Quantity</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="side-nav-item">
                                <a href="javascript: void(0);" class="side-nav-link" aria-expanded="false">
                                    <i class="uil-user"></i>
                                    <span> User Management </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="side-nav-second-level mm-collapse" aria-expanded="false" style="height: 0px;">
                                    <li>
                                        <a href="<?php echo e(route('seller_listing')); ?>">Seller</a>
                                    </li>
                                </ul>
                            </li>
                            <?php else: ?>
                            <li class="side-nav-item">
                                <a href="<?php echo e(route('seller_dashboard')); ?>" class="side-nav-link">
                                    <i class="uil-home-alt"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>
                            <li class="side-nav-item">
                                <a href="<?php echo e(route('product.index')); ?>" class="side-nav-link">
                                    <i class="uil-briefcase"></i>
                                    <span> Products </span>
                                </a>
                            </li>
                            <li class="side-nav-item">
                                <a href="" class="side-nav-link">
                                    <i class="uil-briefcase"></i>
                                    <span> Orders </span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>

                        <div class="clearfix"></div>

                    </div>
                    <!-- Sidebar -left -->

                </div>


            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <div class="navbar-custom">
                        <ul class="list-unstyled topbar-right-menu float-right mb-0">
                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                    aria-expanded="false">
                                    <span class="account-user-avatar"> 
                                        <img src="<?php echo e(url('public/admin/images/users/avatar-1.jpg')); ?>" alt="user-image" class="rounded-circle">
                                    </span>
                                    <span>
                                        <span class="account-user-name"><?php echo e(Auth::user()->display_name); ?></span>
                                        <?php if(Auth::user()->user_type =='1'): ?>
                                        <span class="account-position">Admin</span>
                                        <?php else: ?>
                                        <span class="account-position">Seller</span>
                                        <?php endif; ?>
                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                    <!-- item-->
                                    <!-- item-->
                                    <?php if(Auth::user()->user_type == '2'): ?>  
                                    <a href="<?php echo e(url('seller_profile')); ?>" class="dropdown-item notify-item">
                                        <i class="mdi mdi-account-circle mr-1"></i>
                                        <span>Manage Profile</span>
                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(url('admin_profile')); ?>" class="dropdown-item notify-item">
                                        <i class="mdi mdi-account-circle mr-1"></i>
                                        <span>Manage Profile</span>
                                    </a>
                                    <?php endif; ?>
                                    <!-- item-->
                                    <a href="<?php echo e(url('change_password')); ?>/<?php echo e(base64_encode(Auth::user()->id)); ?>" class="dropdown-item notify-item">
                                        <i class="mdi mdi-account-edit mr-1"></i>
                                        <span>Change Password</span>
                                    </a>
                                    <!-- item-->

                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();" class="dropdown-item notify-item">
                                        <i class="mdi mdi-logout mr-1"></i>
                                        <span>Logout</span>
                                        <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!-- end Topbar -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- Footer Start -->
            <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <?php echo date('Y'); ?> © Hyper
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->
            </div>
            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->
        </div>
        <!-- END wrapper -->

        <!-- bundle -->
        <script src="<?php echo e(url('public/admin/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/app.min.js')); ?>"></script>

        <!-- third party js -->
        <script src="<?php echo e(url('public/admin/js/vendor/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/dataTables.bootstrap4.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/buttons.flash.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/dataTables.select.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/vendor/jquery-jvectormap-world-mill-en.js')); ?>"></script>
        <!-- third party js ends -->

        <!-- demo app -->
        <script src="<?php echo e(url('public/admin/js/pages/demo.datatable-init.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/pages/demo.dashboard.js')); ?>"></script>
        <script src="<?php echo e(url('public/admin/js/pages/demo.profile.js')); ?>"></script>
        <!-- end demo js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
        <script>
         <?php echo $__env->yieldContent('javascript'); ?>
      </script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\ecomm\resources\views/layouts/admin.blade.php ENDPATH**/ ?>