
<?php $__env->startSection('title','Edit Blend Content Name'); ?>
<?php $__env->startSection('content'); ?>
                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Blend Content Master</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title margin-mb">Edit Blend Content Name</h4>
                                        <ul class="nav nav-tabs nav-bordered mb-1">
                                        </ul> <!-- end nav-->
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="custom-styles-preview">
                                                <form id="edit_blend" action="<?php echo e(url('blendContent')); ?>/<?php echo e($id); ?>" method="post">
                                                <?php echo method_field('PATCH'); ?>
                                                <?php echo $__env->make('admin.blendContent.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php echo csrf_field(); ?>
                                                </form>                                            
                                            </div> <!-- end preview-->
                                        </div> <!-- end tab-content-->

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->

                    </div> <!-- container -->

                </div> <!-- content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
$.validator.setDefaults({
        submitHandler : function(form) {
            form.submit();
        }
    });
    $("#edit_blend").validate({

            rules: {
                blend_content_name: "required",
            },

            messages: {
                blend_content_name: "* Enter Blend Name",
            }
        });
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomm\resources\views/admin/blendContent/edit.blade.php ENDPATH**/ ?>