
<?php $__env->startSection('title','Sub-Category Index'); ?>
<?php $__env->startSection('content'); ?>
                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Sub-Category Master</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 

                        <div class="row">
                            <div class="col-12">
                                <?php if(Session::has('danger')): ?>
                                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong><?php echo e(Session::get('danger')); ?></strong> 
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('success')): ?>
                                <div class="alert alert-success alert-dismissible bg-success text-white border-0 fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong><?php echo e(Session::get('success')); ?></strong> 
                                </div>
                                <?php endif; ?>

                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Sub-Category List <span class="add_span_css"><a href="<?php echo e(route('subcategory.create')); ?>" class="btn btn-success">Add</a></span></h4>
                                        <p class="text-muted font-14">
                                        </p>
                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="buttons-table-preview">
                                                <table id="example" class="table table-striped dt-responsive nowrap w-100">
                                                    <thead>
                                                        <tr>
                                                            <th>id</th>
                                                            <th>Category Name</th>
                                                            <th>Sub-Category Name</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    </tbody>
                                                </table>                                           
                                            </div> <!-- end preview-->
                                        </div> <!-- end tab-content-->
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->
                    </div> <!-- container -->
                </div> <!-- content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
$(document).ready(function() {
    $('#example').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": "<?php echo e(route('get_subcategory_data')); ?>",
        "columns" : [
            { "data" : "id"},
            { "data" : "category_name"},
            { "data" : "sub_category_name"},
            { 
              data: 'is_active', 
              render: function(data) { 
                if(data == 'Active') {
                  return '<span class="badge badge-primary">'+data+'</span>' 
                }
                else {
                  return '<span class="badge badge-danger">'+data+'</span>'
                }

              },
            },
            { 
              data: 'id', 
              render: function ( data, type, row ) {
               return '<a href="<?php echo e(url('/subcategory')); ?>/'+data+'/edit" class="action-icon"> <i class="mdi mdi-pencil"></i></a><form action="<?php echo e(url('/subcategory')); ?>/'+data+'" method="POST" class="action-icon"><?php echo method_field('DELETE'); ?><?php echo csrf_field(); ?><button class="action-icon" style="border:none;background: none;"> <i class="mdi mdi-delete"></i></form>'
               }
            },
         ]
    } );
} );
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecomm\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>