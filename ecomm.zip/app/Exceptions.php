<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exceptions extends Model
{
   protected $guarded = [];
}
