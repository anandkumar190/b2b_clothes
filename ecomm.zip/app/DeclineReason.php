<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeclineReason extends Model
{
    protected $guarded = [];
}
